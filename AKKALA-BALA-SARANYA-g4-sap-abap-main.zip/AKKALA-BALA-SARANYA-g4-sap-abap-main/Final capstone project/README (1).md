<div align="center" style="border: 2px solid #ccc; padding: 20px; border-radius: 12px; width: 80%; margin: auto; box-shadow: 0 0 10px rgba(0,0,0,0.15);">
    <img
        width="180"
        height="220"
        alt="Logo - SURE ProEd"
        src="https://github.com/user-attachments/assets/88fa5098-24b1-4ece-87df-95eb920ea721"
        style="border-radius: 10px;"
    />

  <h1 align="center" style="font-family: Arial; font-weight: 600; margin-top: 15px;">SURE ProEd (formerly SURE Trust) 
      </h1>
<h2 style="color: #2b6cb0; font-family: Arial;">Skill Upgradation for Rural youth Empowerment Trust</h2>
</div>

<hr style="border: 0; border-top: 1px solid #ccc; width: 80%;" />

<div style="padding: 20px; border: 2px solid #ddd; border-radius: 12px; width: 90%; margin: auto; background: #fafafa; font-family: Arial;">

<h2 style = "color:#333;"> Student Details </h2>
<div align = "left" style ="margin: 20px; font-size: 16px;">
    <p><strong>Name:</strong> Akkala Bala Saranya </p>
    <p><strong>Email ID:</strong> balasaranyag4sapabap@gmail.com </p>
    <p><strong>College Name:</strong> VKR & VNB College of Engineering, Gudivada </p>
    <p><strong>Branch/Specialization :</strong> CSE (AIML) </p>
    <p><strong>College ID:</strong> 22NH1A4201 </p>
</div>

<hr style="border: 0; border-top: 1px solid #ccc; width: 80%;" />

<h2 style="color:#333;"> Course Details </h2>
<div align="left" style="margin: 20px; font-size: 16px;">
    <p><strong>Course Opted:</strong> SAP ABAP </p>
    <p><strong>Instructor Name:</strong> Mr.Santosh Kumar Pal </p>
</div>
<div align="left" style="margin: 20px; font-size: 16px;">
    <p><strong>Duration:</strong>January-2026 - June-2026 </p>

<hr style="border: 0; border-top: 1px solid #ccc; width: 80%;" />

<h2 style="color:#333;"> Trainer Details </h2>
<div align="left" style="margin: 20px; font-size: 16px;">

<p><strong>Trainer Name:</strong> Mr.Santosh Kumar Pal </p>
<p><strong>Trainer Email ID:</strong> <!–– Add trainer email ––></p>
<p><strong>Trainer Designation:</strong> SAP ABAP Consultant, Infosys Limited </p>

<hr style="border: 0; border-top: 1px solid #ccc; width: 80%;" />

## **Table of Contents**
- [Course Learning](#course-learning-to-be-edited-by-student)
- [Projects Completed](#projects-completed)
- [Project Introduction](#project-introduction)
- [Technologies Used](#technologies-used)
- [Roles and Responsibilities](#roles-and-responsibilities)
- [Project Report](#project-report)
- [Learnings from LST & SST](#learnings-from-lst--sst)
- [Community Services](#community-services)
- [Certificate](#certificate)
- [Acknowledgments](#acknowledgments)

<hr style="border: 0; border-top: 1px solid #ccc; width: 80%;" />


## Overall Learning 

This internship was a great learning experience for me. It gave me the opportunity to understand how the concepts in real projects. By working on different tasks and assignments, I improved my technical knowledge and gained practical experience.

I also learned how important time management, communication, and teamwork are in a professional environment. Whenever I faced difficulties, the guidance from mentors helped me understand my mistakes and improve my approach. Completing tasks on time and learning new concepts increased my confidence and motivated me to keep improving.

Overall, this internship helped me grow both technically and personally. It gave me a better understanding of industry expectations and prepared me to face future career opportunities with more confidence.


<h2 style="color:#333;"> Projects Completed </h2>
<div align="left" style="margin: 20px; font-size: 16px;">

<p><strong><a href="#project1">Project 1:</a></strong> Search Help </p>

<p><strong><a href="#project2">Project 2:</a></strong> ALV Report </p>

<p><strong><a href="#project3">Project 3:</a></strong> Interactive ALV Report </p> 

<p><strong><a href="#project4">Project 4:</a></strong> Module Pool Programming </p> 

<p><strong><a href="#project5">Project 5:</a></strong> Smart Forms </p> 

<p><strong><a href="#project6">Project 6:</a></strong> Business Application Programming Interface (BAPI) </p>

</div>

<!-- Project 1 -->
<h3 id="project1">Project 1: Search Help </h3>
<p>
  Developed Elementary and Collective Search Helps using the LIKP and LIPS tables to enable quick and accurate data retrieval, reducing manual data entry and improving user efficiency.
</p>
<p>
  <a href= "https://github.com/sure-trust/AKKALA-BALA-SARANYA-g4-sap-abap/blob/339eda59613c5b374ea89cef822410991a8ba0a5/Course%20report/SURE%20Trust%20project%20document.pdf" target="_blank"><strong>→ View Full Project Report</strong></a>
</p>

<!-- Project 2 -->
<h3 id="project2">Project 2: ALV Report </h3>
<p>
  Created an ALV report using the MKPF table to display business data in a structured format with features such as sorting, filtering, searching, subtotal calculation, and Excel export.
</p>
<p>
  <a href="https://github.com/sure-trust/AKKALA-BALA-SARANYA-g4-sap-abap/blob/339eda59613c5b374ea89cef822410991a8ba0a5/Course%20report/SURE%20Trust%20project%20document.pdf" target="_blank"><strong>→ View Full Project Report</strong></a>
</p>

<!-- Project 3 -->
<h3 id="project3">Project 3: Interactive ALV Report </h3>
<p>
  Enhanced the ALV report by implementing drill-down functionality, allowing users to view detailed MSEG records from the summary data displayed in the MKPF report.
</p>
<p>
  <a href="https://github.com/sure-trust/AKKALA-BALA-SARANYA-g4-sap-abap/blob/339eda59613c5b374ea89cef822410991a8ba0a5/Course%20report/SURE%20Trust%20project%20document.pdf" target="_blank"><strong>→ View Full Project Report</strong></a>
</p>

<!-- Project 4 -->
<h3 id="project4">Project 4: Module Pool Programming </h3>
<p>
  Developed interactive SAP screens using Table Controls and Tabstrip Controls to perform data entry, display, update, and navigation in a user-friendly interface.
</p>
<p>
  <a href="https://github.com/sure-trust/AKKALA-BALA-SARANYA-g4-sap-abap/blob/339eda59613c5b374ea89cef822410991a8ba0a5/Course%20report/SURE%20Trust%20project%20document.pdf" target="_blank"><strong>→ View Full Project Report</strong></a>
</p>

<!-- Project 5 -->
<h3 id="project5">Project 5: Smart Forms </h3>
<p>
  Designed Smart Forms to generate professional business documents with dynamic data, formatted layouts, headers, footers, and print/PDF support.
</p>
<p>
  <a href="https://github.com/sure-trust/AKKALA-BALA-SARANYA-g4-sap-abap/blob/339eda59613c5b374ea89cef822410991a8ba0a5/Course%20report/SURE%20Trust%20project%20document.pdf" target="_blank"><strong>→ View Full Project Report</strong></a>
</p>

<!-- Project 6 -->
<h3 id="project6">Project 6: BAPI Development </h3>
<p>
  Implemented BAPI programs to automate the creation of Sales Orders and Purchase Orders using standard SAP Business Objects, ensuring reliable and efficient transaction processing.
</p>
<p>
  <a href="https://github.com/sure-trust/AKKALA-BALA-SARANYA-g4-sap-abap/blob/339eda59613c5b374ea89cef822410991a8ba0a5/Course%20report/SURE%20Trust%20project%20document.pdf" target="_blank"><strong>→ View Full Project Report</strong></a>
</p>

<hr style="height:1px; border-top:1px solid #ccc; width:80%;" />


## **References**

- [Wikipedia](https://wikipedia.com)
<!--you can add refrences over here in same syntax as above -->
---


## **Learnings from LST and SST**

The LST (Life Skills Training) and SST (Soft Skills Training) sessions helped me improve both my personal and professional skills. I learned the importance of effective communication, teamwork, time management, problem-solving, and maintaining a positive attitude in the workplace.

These sessions also helped me build confidence in speaking, presenting ideas, and interacting with others. I understood the value of discipline, adaptability, leadership, and continuous learning for personal and career growth.

Overall, LST and SST complemented my technical learning by helping me develop the soft skills required to work effectively in a professional environment and prepared me to face interviews and workplace challenges with greater confidence.

## **Community Services**

<!-- add descreption in your own words -->

During my internship period, I participated in multiple community-oriented activities .....<!-- add descreption in your own words -->

### **Activities Involved**

- **Tree Plantation Drive** – **[Nimmakuru, Andhra Pradesh]** 
  Participated by planting trees and contributing to environmental improvement.Participated in a tree plantation drive by planting saplings to promote environmental conservation and create a greener, healthier surroundings.

- **Helping Elder Citizens** – **[Machilipatnam, Andhra Pradesh]**
  Assisted two elderly individuals with simple daily activities and offered support whenever needed, making their routine tasks easier and providing companionship.

### **Impact / Contribution**

- These community service activities allowed me to make a small but meaningful contribution to society.
-  The tree plantation drive helped promote environmental awareness, while assisting elderly citizens strengthened my compassion, patience, and sense of social responsibility.
-  Overall, these experiences taught me the value of community service and inspired me to continue participating in initiatives that benefit society.

### **Photos**

<div align="center">
<img src="https://github.com/user-attachments/assets/f90ca89a-e883-4fc4-a865-6c98f89d9f8e" />

" alt="Community Service Photo 1" width="30%">
    
<img src = "https://github.com/user-attachments/assets/bd200aea-63c4-4502-b3d3-8da7c3a222a0" />
 alt="Community Service Photo 2" width="30%">
</div>

---

## **Certificate**

The internship certificate serves as an official acknowledgment of the successful completion of my training period. It will be issued by the organization upon fulfilling all required tasks and meeting the performance expectations of the program. The certificate validates the skills, experience, and contributions made during the internship.

<!-- add your certificate image url below (inside src='')-->

<p align="center">
<img src="https://github.com/Lord-Rahul/Practice-Programs/blob/main/react/1/public/Gemini_Generated_Image_a6w8rda6w8rda6w8.png?raw=true" alt="Internship Certificate" width="80%">
</p>

---

## **Acknowledgments**

<!-- you can add Acknowledgments over here in same syntax as below . eg trainer name , company name , role etc -->

- [Prof. Radhakumari Challa](https://www.linkedin.com/in/prof-radhakumari-challa-a3850219b) , Executive Director and Founder - [SURE Trust](https://www.suretrustforruralyouth.com/)

